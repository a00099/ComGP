

#ifndef EFFECT__H__
#define EFFECT__H__

#include "Point3d.h"
#include "Cube.h"
#include <gl/glut.h>
#include <stdlib.h>
#include "baseobj.h"
#include <math.h>

#define RAD 57.32

class effect :public baseobj{
public:
	//�ִϸ��̼�
	//��Ȳ���°� ������������ kind1 ����        2 ~~ init 
	Cube fireball[4];
	Cube icestrike[9];
	Cube colliderbox;
	//int fireballrange = 100;
	int leggacdo = 0;
	int standtime = 0;
	int gacdostate = 0;
	Point3d gacdopos;
	int objgacdo = 0;

	int movecount = 10;
	int attackdistance = 70;
	int followmode = 0;
	int MState = 0;
	int animationcount = 5;
	int effectkind = 0;
	int effecttime =0;
	double yspeed = 0;
	int damage = 70;

	effect(int x, int y, int z,int ekind=0)
	{
		effectkind =ekind;
		if (effectkind == 0)
		{
			//effecttime = 200;
			effecttime = 60;
			pos.x = x;
			pos.y = y;
			pos.z = z;

			//���� x y ��ũ�� 30
			/*
			collidersize.x = 30;
			collidersize.y = 30;
			collidersize.z = -78;
			*/
			collidersize.x = 80;
			collidersize.y = 100;
			collidersize.z = -80;
			for (int i = 0; i < 4; ++i)
				fireball[i].setcolor(1, 0, 0.1*i);


			damage = 70;
		}

		if (effectkind == 1)
		{
			yspeed = 0;
			pos.x = x;
			pos.y = y;
			pos.z = z;
			effecttime = 500;
			collidersize.x = 200*2;
			collidersize.y = 200*2;
			collidersize.z = -200*2;
			for (int i = 0; i < 9; ++i)
				icestrike[i].setcolor(0,0,255);


			damage = 250;
		}

	}

	void update()
	{
		if (effectkind == 0)
		{

			if (effecttime >= 0)
			{
				effecttime -= 1;
			}
			//�ӵ� ���ǵ� 10
			pos.x -= 30 * sin(gacdostate / RAD);
			pos.z -= 30 * cos(gacdostate / RAD);

			colliderbox.init(pos.x, pos.y, pos.z, collidersize.x, collidersize.y, -collidersize.z);
			fireball[0].init(pos.x + 11, pos.y + 11, pos.z, 8, 8, 8);
			fireball[1].init(pos.x + 7, pos.y + 7, pos.z - 8, 16, 16, 16);
			fireball[2].init(pos.x + 3, pos.y + 3, pos.z - 24, 24, 24, 24);
			fireball[3].init(pos.x, pos.y, pos.z - 48, 30, 30, 30);

			//30 30 30 -48 ����  -48~-78 �Ѱű�. �� ������ 2��°���ó. ��  x�� 15 y�� 15 -20.
			for (int i = 0; i < 4; ++i)
				fireball[i].update();

		}


		if (effectkind == 1){
			//static double time = 0;
			if (yspeed == 0)
			{
				yspeed = 0.05* (3+rand()%3);
			}
			pos.y -=yspeed*(100+500-effecttime);
			
			//pos.x -= 10 * sin(gacdostate / RAD);
			//pos.z -= 10 * cos(gacdostate / RAD);
			//y��ó��
			if (effecttime >= 0)
			{
				effecttime -= 1;
			}
			colliderbox.init(pos.x, pos.y+200, pos.z, collidersize.x, collidersize.y, -collidersize.z);
			//colliderbox.init(pos.x, pos.y, pos.z, collidersize.x, collidersize.y, -collidersize.z);
			
			/* */
			
				icestrike[5].init(pos.x + 20*2, pos.y + 110*2, pos.z - 20*2, 160*2, 20*2, 160*2);
				icestrike[6].init(pos.x + 40*2, pos.y + 130*2, pos.z - 40*2, 120*2, 20*2, 120*2);
				icestrike[7].init(pos.x + 60*2, pos.y + 150*2, pos.z - 60*2, 80*2, 20*2, 80*2);
				icestrike[8].init(pos.x + 80*2, pos.y +170*2, pos.z -80*2, 40*2, 20*2, 40*2);//100  100���������Ѵ�
				icestrike[4].init(pos.x, pos.y+90*2, pos.z, 200*2, 20*2, 200*2);				
				icestrike[3].init(pos.x+20*2 , pos.y + 70*2, pos.z-20*2 , 160*2, 20*2, 160*2);
				icestrike[2].init(pos.x+40*2 , pos.y + 50*2, pos.z-40*2 , 120*2, 20*2, 120*2);
				icestrike[1].init(pos.x+60*2 , pos.y +30*2, pos.z-60*2 , 80*2, 20*2, 80*2);
				icestrike[0].init(pos.x+80*2 , pos.y +10*2, pos.z-80*2 , 40*2, 20*2, 40*2);//100  100���������Ѵ�
			  

			
				
			//icestrike[0].init(pos.x+100, pos.y+70, pos.z, 100, 40, 40);
			//icestrike[4].init(pos.x + 80, pos.y, pos.z - 80, 40, 200, 40);
			//icestrike[5].init(pos.x , pos.y+80, pos.z , 200, 40, 200);

			/*
			icestrike[1].init(pos.x + 12 * 1, pos.y + 36 * 1, pos.z + 12 * 1, 20 + 36 * 1, 36, 20 + 12 * 1);
			icestrike[2].init(pos.x + 12 * 2, pos.y + 36 * 2, pos.z + 12 * 2, 20 + 36 * 2, 36, 20 + 12 * 2);
			 icestrike[3].init(pos.x + 12 * 3, pos.y + 36 * 3, pos.z+ 12 * 3,20 + 36* 3, 36, 20 + 12 * 3);
			icestrike[4].init(pos.x + 12 * 4, pos.y + 36 * 4, pos.z + 12 * 4, 20 + 36 * 4, 36, 20 + 12 * 4);
			icestrike[5].init(pos.x + 12 * 5, pos.y + 36 * 5, pos.z + 12 * 5, 20 + 36 * 5, 36, 20 + 12 * 5);
			icestrike[6].init(pos.x + 12 * 4, pos.y + 36 * 6, pos.z + 12 * 4, 20 + 36 * 4, 36, 20 + 12 * 4);
			icestrike[7].init(pos.x + 12 * 3, pos.y + 36 * 7, pos.z + 12 * 3, 20 + 36 * 3, 36, 20 + 12 * 3);
			icestrike[8].init(pos.x + 12 * 2, pos.y + 36 * 8, pos.z + 12 * 2, 20 + 36 * 2, 36, 20 + 12 * 2);
			icestrike[9].init(pos.x + 12 * 1, pos.y + 36 * 9, pos.z + 12 * 1, 20 + 36 * 1, 36, 20 + 12 * 1);
			icestrike[10].init(pos.x, pos.y, pos.z, 20, 36, 20);
			  */
					// 0,0,0
				  

			for (int i = 0; i < 9; ++i)
				icestrike[i].update();
		}
	}


	int collider(baseobj *obj)
	{
		////if������Ʈ�̸��� floor�ΰ�� y���浹üũ�� 
		//if ((obj->pos.x<(pos.x + (collidersize.x / 2))) && (obj->pos.x + obj->collidersize.x>(pos.x + (collidersize.x / 2))))
		//{
		//   if ((obj->pos.z > (pos.z + (collidersize.z / 2))) && (obj->pos.z + obj->collidersize.z < (pos.z + (collidersize.z / 2))))

		//   {
		//      if ((pos.y - (obj->pos.y + obj->collidersize.y)) >= 0 && (pos.y - (obj->pos.y + obj->collidersize.y)) <= 10)
		//      {
		//         //�ٴڰ� ĳ���� ĳ��-�ٴ��� 0~10�����ΰ��
		//         if (minpos[0] == -1 && maxpos[0] == -1)
		//         {
		//            minpos[0] = obj->pos.x + obj->collidersize.x;
		//            maxpos[0] = obj->pos.x;

		//            minpos[1] = obj->pos.z + obj->collidersize.z;
		//            maxpos[1] = obj->pos.z;

		//         }

		//         pos.y = obj->pos.y + obj->collidersize.y;
		//         return 1;
		//      }
		//   }
		//}

		return 0;
	}

	void draw()
	{
		

		//colliderbox.draw();
		//glLoadIdentity();
		  
		//��ġ�´޶� ȸ�����̰��ƾ��Ѵ�.
		if (effectkind == 0)
		{
			glTranslatef(pos.x + 15, pos.y + 15,pos.z - 25);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-(pos.x + 15), -(pos.y + 15 ), -(pos.z - 25) );
			fireball[0].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 15, pos.y + 15, pos.z - 25);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-(pos.x + 15), -(pos.y + 15), -(pos.z - 25));
			fireball[1].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 15, pos.y + 15, pos.z - 25);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-(pos.x + 15), -(pos.y + 15), -(pos.z - 25));
			fireball[2].draw();
			glLoadIdentity();

			glTranslatef(pos.x + 15, pos.y + 15, pos.z - 25);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-(pos.x + 15), -(pos.y + 15), -(pos.z - 25));

			fireball[3].draw();
			glLoadIdentity();
			/*
			glTranslatef(fireball[3].pos.x + 20, fireball[3].pos.y + 50, fireball[3].pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-fireball[3].pos.x - 20, -fireball[3].pos.y - 50, -fireball[3].pos.z + 10);
			fireball[0].draw();
			glLoadIdentity();

			glTranslatef(fireball[3].pos.x + 20, fireball[3].pos.y + 50, fireball[3].pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-fireball[3].pos.x - 20, -fireball[3].pos.y - 50, -fireball[3].pos.z + 10);
			fireball[1].draw();
			glLoadIdentity();

			glTranslatef(fireball[3].pos.x + 20, fireball[3].pos.y + 50, fireball[3].pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-fireball[3].pos.x - 20, -fireball[3].pos.y - 50, -fireball[3].pos.z + 10);
			fireball[2].draw();
			glLoadIdentity();

			glTranslatef(fireball[3].pos.x + 20, fireball[3].pos.y + 50, fireball[3].pos.z - 10);
			glRotatef(gacdostate, 0, 1, 0);
			glTranslatef(-fireball[3].pos.x - 20, -fireball[3].pos.y - 50, -fireball[3].pos.z + 10);

			fireball[3].draw();
			glLoadIdentity();

			*/
		}

		if (effectkind == 1)
		{
			//colliderbox.draw();
			//glLoadIdentity();
			for (int i = 0; i < 9; i++)
			{
				
				glTranslatef(pos.x + 100*2, pos.y + 100*2, pos.z-100*2);
				glRotatef(45, 0, 0, 1);
				glTranslatef(-(pos.x + 100*2), -(pos.y + 100*2), -(pos.z-100*2));
				
				

				icestrike[i].draw();
				glLoadIdentity();

			}
			//glTranslatef(100, 0, 0);
			//0 0 0 draw���� -100~100

			/*
			icestrike[0].draw();
			for (int i = 0; i < 36; ++i){
				
				
				
				glTranslatef(pos.x+100, pos.y + 70, pos.z );
				glRotatef(i * 45, 1, 1,0);
				glTranslatef(-(pos.x+100), -(pos.y + 70), -(pos.z));
				icestrike[0].draw();
				glLoadIdentity();
				  
				
				glTranslatef(pos.x+100, pos.y + 70, pos.z);
				glRotatef(i *45, 0, 1, 1);
				glTranslatef(-(pos.x+100), -(pos.y + 70), -(pos.z));
				icestrike[0].draw();
				glLoadIdentity();

				glTranslatef(pos.x + 100, pos.y + 70, pos.z);
				glRotatef(i * 45, 1, 0, 1);
				glTranslatef(-(pos.x + 100), -(pos.y + 70), -(pos.z));
				icestrike[0].draw();
				glLoadIdentity();


				glTranslatef(pos.x + 100, pos.y + 70, pos.z);
				glRotatef(i * 45, -1, 0, -1);
				glTranslatef(-(pos.x + 100), -(pos.y + 70), -(pos.z));
				icestrike[0].draw();
				glLoadIdentity();

				
			}
		*/
		}

	}


};

#endif