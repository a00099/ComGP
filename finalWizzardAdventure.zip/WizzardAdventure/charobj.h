#ifndef CHAROBJ__H__
#define CHAROBJ__H__
#include<gl/glut.h>
#include "Cube.h"
#include "Point3d.h"
#include<stdio.h>
class charobj:public baseobj
{
public:
	//�ִϸ��̼�
	Cube leg[2];
	Cube body;
	Cube arm[2];
	Cube head;
	Cube wand;
	Cube aim;

	Cube HPbar;

	Cube colliderbox;
	

	int wandlevel = 0;
	int damage = 70;
	int fullhp = 0;
	int hp = 0;
	int mp = 0;
	int yspeed = 0;
	int xspeed = 5;
	int level = 1;
	int fullexp = 50;
	int exp = 0;
	int gravitymode = 0;
	int jumpcount = 0;
	int leggacdo = 0;
	int standtime = 0;
	double mychargacdostate = 0;
	int attackstate = 0;
	int attackgacdo = 0;
	Point3d gacdopos;
	int attacktime = 0;
	int CharState = 0;
	int gravityaccel = 0;
	int gravitytime = 0;
	int obstaclecheck = 0;
	int keykode = 0;
	charobj(int ilevel, int ihp, int imp, int x,int y,int z)
	{
		fullhp = ihp;
		//ĳ����ũ��� 60����?
		level = ilevel;
		hp = ihp;
		mp = imp;
		pos.x=x;
		pos.y = y;
		pos.z = z;
		//leg[0].init(-30, 0, 0, 20, 60, 20);
		//leg[1].init(30, 0, 0, 20, 60, 20);
	//	collidersize.x = 100;
	//	collidersize.y = 100;
	//	collidersize.z = -40;
		collidersize.x = 60;
		collidersize.y = 120;
		collidersize.z = -40;

		leg[0].setcolor(0, 0, 0);
		leg[1].setcolor(0, 0, 0);
		body.setcolor(125, 125, 0 );
		arm[0].setcolor(0, 1, 0);
		arm[1].setcolor(0, 1, 0);

		HPbar.setcolor(1, 0, 0);
	}

	void update()
	{
		
		
		colliderbox.init(pos.x, pos.y , pos.z, collidersize.x, collidersize.y, -collidersize.z);
		if (attacktime<=100 && attacktime>50)
		{
			//2��������?
			if (attacktime%1==0)
			attackgacdo += 2;
			attacktime-=2;
		}
		else  if (attacktime<=50 && attacktime>0)
		{
			if (attacktime % 1 == 0)
			attackgacdo -= 2;
			attacktime-=2;
		}
		if (attacktime <= 0 && attackstate==1)
		{
			attackstate = 0;
		}


		if (standtime > 100)
		{
			leggacdo = 0;
			standtime = 0;
		}
		else
		{
			standtime++;
		}
		if (jumpcount > 0)
		{
			pos.y += 15;
			jumpcount--;
		}
		if (gravitymode == 0)
		{
			//pos.y -= 9.8;
			gravitytime = 0;
		}
		if (gravitymode == 1 &&jumpcount==0)
		{
			pos.y -= 2*(1+gravityaccel*0.1);
			gravityaccel+=1;
			gravitytime++;
		}

		HPbar.init(pos.x-55 , pos.y + 150, pos.z + 15,(hp)*2, 30, 30);
		leg[0].init(pos.x+15, pos.y+0, pos.z-15,10,50,10);
		leg[1].init(pos.x + 35, pos.y + 0, pos.z -15, 10, 50, 10);
		body.init(pos.x +10, pos.y+50, pos.z-10, 40, 50, 20);
		arm[0].init(pos.x + 0, pos.y + 60, pos.z - 15, 10, 35, 10);
		arm[1].init(pos.x + 50, pos.y + 60, pos.z -15, 10, 35, 10);
		head.init(pos.x + 20, pos.y + 100, pos.z-10, 20, 20, 20);
		wand.init(pos.x + 52, pos.y + 62, pos.z - 25, 6, 6, 50);
		//aim.init(pos.x, pos.y + 100, pos.z - 50, 1000, 100, 100);
		gacdopos.x = body.pos.x + 20;
		gacdopos.y = body.pos.y + 50;
		gacdopos.z = body.pos.z - 10;
		/*
		leg[0].update();
		leg[1].update();
		body.update();
		arm[0].update();
		arm[1].update();
		*/
		//aim.update();
		/*
		head.update();
		wand.update();
		  */

	}
	int hitcollider(baseobj *obj)
	{
		//���� y�����̿� �ְ�  x z �൵ ���̿��ִ°��.		  //����Ʈ x���� ����+���丷�����ΰ��.
		int xsize = collidersize.x / 2;
	


		//x�񱳴� ������ x��- ����Ʈx��-ũ��� �� ����.
		//	if (((pos.x + xsize - obj->pos.x - (collidersize.x / 2)))>-70 && ((pos.x + xsize - obj->pos.x - (collidersize.x / 2)))<70)
		if (obj->pos.x - pos.x >-(obj->collidersize.x ) && obj->pos.x - pos.x <  (obj->collidersize.x ))
		{ 
			//printf("x�� ���� /n");
			//���� �߾Ӱ�-�ĺ����߾Ӱ����� ĳ�����븸�Ѱ��
			//if ((obj->pos.y<(pos.y + (collidersize.y / 2))) && ((obj->pos.y + obj->collidersize.y)>(pos.y + (collidersize.y / 2))))
			//{


				//	if (obj->pos.z - pos.z > -(obj->collidersize.z/2) && obj->pos.z - pos.z < 100)	 //���Ϳ� ������z�ప�����̰� 100����
				if (obj->pos.z - pos.z >(obj->collidersize.z ) && obj->pos.z - pos.z <  -(obj->collidersize.z ))	 //���Ϳ� ������z�ప�����̰� 100����
				{
					return 1;
				}
			//}

		}
		//���Ϳ� 
		return 0;
	}

	void attackmode()
	{
		attackstate=1;
		attacktime = 100;
	}
	int collider(baseobj *obj)
	{
		//if������Ʈ�̸��� floor�ΰ�� y���浹üũ�� 
		//obj floor
		if ((obj->pos.x<(pos.x + (collidersize.x / 2))) && (obj->pos.x + obj->collidersize.x>(pos.x+(collidersize.x / 2))) )
		{
			if ((obj->pos.z>(pos.z + (collidersize.z / 2))) && (obj->pos.z + obj->collidersize.z<(pos.z + (collidersize.z / 2))))
			
			{
				if ( (pos.y - (obj->pos.y + obj->collidersize.y ) ) >= -50 && (pos.y - (obj->pos.y + obj->collidersize.y )) <=10 )
				{
					//�ٴڰ� ĳ���� ĳ��-�ٴ��� 0~10�����ΰ��
					
					pos.y = obj->pos.y + obj->collidersize.y;
					return 1;
				}
			}
		}

		return 0;
	}


	int movecollider(baseobj *obj)
	{
		//printf("�Լ�ȣ��̴� \n");
		//h�� obj p�� ���系�� ����
		//if (obj->pos.y - pos.y > -3 && obj->pos.y - pos.y < 3) //�ݴ� h�� ���� ���� obj�� floor ������
		if ((obj->pos.y<(pos.y + (collidersize.y / 2))) && ((obj->pos.y + obj->collidersize.y)>(pos.y + (collidersize.y / 2))))
		//if (1)
		{		  //��ĳ���� ������ pos y���̰�.
			//	printf("y�̴� \n");
				if (obj->pos.x-10<pos.x + collidersize.x/2 && obj->pos.x+obj->collidersize.x+10>pos.x + collidersize.x / 2)
			{
				//	printf("x�̴� \n");
				//��ĳ������ ������ ��ܻ���

				
			
				if (obj->pos.z + obj->collidersize.z < pos.z-collidersize.z &&  obj->pos.z+140> pos.z-collidersize.z)
				{
					//printf("z�̴� \n");
				
					return 2;
				}

			
			}
		}
		return 0;
	}
	void draw()
	{
		//colliderbox.draw();
		//glLoadIdentity();

		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
		HPbar.draw();
		glLoadIdentity();
		//glNormal3f(0, 1.0, 0);
		//glRotatef(mychargacdostate, 0, 1, 0);
	//	glNormal3f(0, 0, 1);
		/*glTranslatef(leg[0].pos.x + 5, leg[0].pos.y + 50, leg[0].pos.z - 5);//������ġ���� ȸ������ �ٽ� �������ؿ��� �ٽñ׷��ش�
		glRotatef(mychargacdostate, 0, 1, 0);
		glRotatef(leggacdo * 20, 1, 0, 0);
		glTranslatef(-leg[0].pos.x - 5, -leg[0].pos.y - 50, -leg[0].pos.z + 5);
		  */
		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glRotatef(leggacdo * 10, 1, 0, 0);
		glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
		//leg[0].setxgacdo(leggacdo * 40);
		leg[0].draw();
		glLoadIdentity();

		//leg[1].setxgacdo(-leggacdo * 40);
		//glRotatef(mychargacdostate, 0, 1, 0);
		/*
		glTranslatef(leg[1].pos.x + 5, leg[1].pos.y + 50, leg[1].pos.z - 5);//������ġ���� ȸ������ �ٽ� �������ؿ��� �ٽñ׷��ش�
		glRotatef(mychargacdostate, 0, 1, 0);
		glRotatef(-leggacdo * 20, 1, 0, 0);
		glTranslatef(-leg[1].pos.x - 5, -leg[1].pos.y - 50, -leg[1].pos.z + 5);
							*/
		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glRotatef(-leggacdo * 10, 1, 0, 0);
		glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);

		leg[1].draw();
		glLoadIdentity();

		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
		body.draw();
		glLoadIdentity();

		/*
		glTranslatef(arm[0].pos.x + 30, arm[0].pos.y + 60, arm[0].pos.z - 20);
		glRotatef(mychargacdostate, 0, 1, 0);
		glTranslatef(-arm[0].pos.x - 30, -arm[0].pos.y - 60, -arm[0].pos.z + 20);
		*/
		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glRotatef(attackgacdo, 1, 0, 0); //������°� 
			glTranslatef(-body.pos.x -  20, -body.pos.y - 50, -body.pos.z + 10);

		arm[0].draw();
		glLoadIdentity();

		/*
		glTranslatef(arm[1].pos.x + 30, arm[1].pos.y + 60, arm[1].pos.z - 20);
		glRotatef(mychargacdostate, 0, 1, 0);
		glTranslatef(-arm[1].pos.x -30, -arm[1].pos.y -60, -arm[1].pos.z + 20);
		*/
		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glRotatef(attackgacdo, 1, 0, 0);
		glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
		arm[1].draw();
		glLoadIdentity();

		/*
		glTranslatef(head.pos.x + 10, head.pos.y + 10, head.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glTranslatef(-head.pos.x - 10, -head.pos.y - 10, -head.pos.z + 10);
		*/
		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);

		head.draw();
		//glTranslatef(0, 0, -100);
		//aim.draw();
		glLoadIdentity();

		/*
		glTranslatef(wand.pos.x+3, wand.pos.y + 3, wand.pos.z );
		glRotatef(mychargacdostate, 0, 1, 0);
		glTranslatef(-wand.pos.x-3, -wand.pos.y - 3, -wand.pos.z );
		*/
		glTranslatef(body.pos.x + 20, body.pos.y + 50, body.pos.z - 10);
		glRotatef(mychargacdostate, 0, 1, 0);
		glRotatef(attackgacdo, 1, 0, 0);
		glTranslatef(-body.pos.x - 20, -body.pos.y - 50, -body.pos.z + 10);
		wand.draw();
		glLoadIdentity();
		/*
		//wand.init(0, 0, 0, 6, 6, 50);
		glRotatef(mychargacdostate, 0, 1, 0);
		wand.init(pos.x + 52, pos.y + 62, pos.z - 25, 6, 6, 50);
		wand.draw();

		glLoadIdentity();
		  */
	}


};









#endif