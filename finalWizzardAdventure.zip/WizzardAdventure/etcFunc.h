#ifndef ETCFUNC__H__
#define ETCFUNC__H__
#include <gl/glut.h>
#include "Point3d.h"
#include "Cube.h"
#include "baseobj.h"
