
#ifndef CUBE__H__
#define CUBE__H__
#include<gl/glut.h>
#include "Point3d.h"
#include "baseobj.h"

class Cube:public baseobj{
private:
	//double cubeSize = 50.0;
public:
	//���ư��¼����� -�� ������ ������.
	Point3d color;
	double cubeSize[3];
//	Point3d pos;
	Point3d bottomPoint[4];
	Point3d topPoint[4];
	Point3d xPlane[2][4];
	Point3d yPlane[2][4];
	Point3d zPlane[2][4];
	Point3d gacdo;
	Point3d gacdostate;
	Cube(){   }

	Cube(float x, float y, float z,double xcubesize=50,double ycubesize=50,double zcubesize=50){
		color.x = 1;
		color.y = 1;
		color.z = 1;
		cubeSize[0] = xcubesize;
		cubeSize[1] = ycubesize;
		cubeSize[2] = zcubesize;
		pos.x = x;
		pos.y = y;
		pos.z = z;
		for (int i = 0; i < 4; ++i){
			if (i == 0){
				bottomPoint[i].init(x, y, z);
				topPoint[i].init(x, y + cubeSize[1], z);
			}
			else if (i == 1){
				bottomPoint[i].init(x + cubeSize[0], y, z);
				topPoint[i].init(x + cubeSize[0], y + cubeSize[1], z);
			}
			else if (i == 2){
				bottomPoint[i].init(x + cubeSize[0], y, z - cubeSize[2]);
				topPoint[i].init(x + cubeSize[0], y + cubeSize[1], z - cubeSize[2]);
			}
			else if (i == 3){
				bottomPoint[i].init(x, y, z - cubeSize[2]);
				topPoint[i].init(x, y + cubeSize[1], z - cubeSize[2]);
			}
		}

		xPlane[0][0] = bottomPoint[0];
		xPlane[0][1] = bottomPoint[3];
		xPlane[0][2] = topPoint[3];
		xPlane[0][3] = topPoint[0];

		xPlane[1][0] = bottomPoint[1];
		xPlane[1][1] = bottomPoint[2];
		xPlane[1][2] = topPoint[2];
		xPlane[1][3] = topPoint[1];

		yPlane[0][0] = bottomPoint[0];
		yPlane[0][1] = bottomPoint[1];
		yPlane[0][2] = bottomPoint[2];
		yPlane[0][3] = bottomPoint[3];

		yPlane[1][0] = topPoint[0];
		yPlane[1][1] = topPoint[1];
		yPlane[1][2] = topPoint[2];
		yPlane[1][3] = topPoint[3];

		zPlane[0][0] = bottomPoint[0];
		zPlane[0][1] = bottomPoint[1];
		zPlane[0][2] = topPoint[1];
		zPlane[0][3] = topPoint[0];

		zPlane[1][0] = bottomPoint[3];
		zPlane[1][1] = bottomPoint[2];
		zPlane[1][2] = topPoint[2];
		zPlane[1][3] = topPoint[3];

	}

	void setcolor(float x, float y, float z)
	{
		color.x = x;
		color.y = y;
		color.z = z;
	}
	Point3d Normalvec(Point3d v1, Point3d v2)
	{
		Point3d result;
		
		result.x = v1.y*v2.z - v1.z*v2.y;
		result.y = v1.z*v2.x - v1.x*v2.z;
		result.z = v1.x*v2.y - v1.y*v2.x;
		  

		/*
		result.x = (v1.y*-v2.z) - (-v1.z*v2.y);
		result.y =  (-v1.z*v2.x) - (v1.x*-v2.z);
		result.z = (v1.x*v2.y) - (v1.y*v2.x );
		  */
		return result;
	}
	void init(float x, float y, float z, double xcubesize = 50, double ycubesize = 50, double zcubesize = 50){
		cubeSize[0] = xcubesize;
		cubeSize[1] = ycubesize;
		cubeSize[2] = zcubesize;

		gacdo.x = 0;
		gacdo.y = 0;
		gacdo.z = 0;
		pos.x = x;
		pos.y = y;
		pos.z = z;
		for (int i = 0; i < 4; ++i){
			if (i == 0){
				bottomPoint[i].init(x, y, z);
				topPoint[i].init(x, y + cubeSize[1], z);
			}
			else if (i == 1){
				bottomPoint[i].init(x + cubeSize[0], y, z);
				topPoint[i].init(x + cubeSize[0], y + cubeSize[1], z);
			}
			else if (i == 2){
				bottomPoint[i].init(x + cubeSize[0], y, z - cubeSize[2]);
				topPoint[i].init(x + cubeSize[0], y + cubeSize[1], z - cubeSize[2]);
			}
			else if (i == 3){
				bottomPoint[i].init(x, y, z - cubeSize[2]);
				topPoint[i].init(x, y + cubeSize[1], z - cubeSize[2]);
			}
		}
	  
	
		/*
		for (int i = 0; i < 4; ++i){
			if (i == 0){
				bottomPoint[i].init(0, 0, 0);
				topPoint[i].init(0, 0 + cubeSize[1], 0);
			}
			else if (i == 1){
				bottomPoint[i].init(0 + cubeSize[0], 0, 0);
				topPoint[i].init(0 + cubeSize[0], 0 + cubeSize[1], 0);
			}
			else if (i == 2){
				bottomPoint[i].init(0 + cubeSize[0], 0, 0 - cubeSize[2]);
				topPoint[i].init(0 + cubeSize[0], 0 + cubeSize[1], 0 - cubeSize[2]);
			}
			else if (i == 3){
				bottomPoint[i].init(0, 0, 0 - cubeSize[2]);
				topPoint[i].init(0, 0 + cubeSize[1], 0 - cubeSize[2]);
			}
		}
			 */
		xPlane[0][0] = bottomPoint[0];
		xPlane[0][1] = bottomPoint[3];
		xPlane[0][2] = topPoint[3];
		xPlane[0][3] = topPoint[0];

		xPlane[1][0] = bottomPoint[1];
		xPlane[1][1] = bottomPoint[2];
		xPlane[1][2] = topPoint[2];
		xPlane[1][3] = topPoint[1];

		yPlane[0][0] = bottomPoint[0];
		yPlane[0][1] = bottomPoint[1];
		yPlane[0][2] = bottomPoint[2];
		yPlane[0][3] = bottomPoint[3];

		yPlane[1][0] = topPoint[0];
		yPlane[1][1] = topPoint[1];
		yPlane[1][2] = topPoint[2];
		yPlane[1][3] = topPoint[3];

		zPlane[0][0] = bottomPoint[0];
		zPlane[0][1] = bottomPoint[1];
		zPlane[0][2] = topPoint[1];
		zPlane[0][3] = topPoint[0];

		zPlane[1][0] = bottomPoint[3];
		zPlane[1][1] = bottomPoint[2];
		zPlane[1][2] = topPoint[2];
		zPlane[1][3] = topPoint[3];

	}
	void update()
	{
		
      //�ǽð����� �����̰��ϱ�����.
		
		for (int i = 0; i < 4; ++i){
			if (i == 0){
				bottomPoint[i].init(pos.x, pos.y, pos.z);
				topPoint[i].init(pos.x, pos.y + cubeSize[1], pos.z);
			}
			else if (i == 1){
				bottomPoint[i].init(pos.x + cubeSize[0], pos.y, pos.z);
				topPoint[i].init(pos.x + cubeSize[0], pos.y + cubeSize[1], pos.z);
			}
			else if (i == 2){
				bottomPoint[i].init(pos.x + cubeSize[0], pos.y, pos.z - cubeSize[2]);
				topPoint[i].init(pos.x + cubeSize[0], pos.y + cubeSize[1], pos.z - cubeSize[2]);
			}
			else if (i == 3){
				bottomPoint[i].init(pos.x, pos.y, pos.z - cubeSize[2]);
				topPoint[i].init(pos.x, pos.y + cubeSize[1], pos.z - cubeSize[2]);
			}
		}
		  
		/*
		for (int i = 0; i < 4; ++i){
			if (i == 0){
				bottomPoint[i].init(0, 0, 0);
				topPoint[i].init(0, 0 + cubeSize[1], 0);
			}
			else if (i == 1){
				bottomPoint[i].init(0 + cubeSize[0], 0, 0);
				topPoint[i].init(0 + cubeSize[0], 0 + cubeSize[1], 0);
			}
			else if (i == 2){
				bottomPoint[i].init(0 + cubeSize[0], 0, 0 - cubeSize[2]);
				topPoint[i].init(0 + cubeSize[0], 0 + cubeSize[1], 0 - cubeSize[2]);
			}
			else if (i == 3){
				bottomPoint[i].init(0, 0, 0 - cubeSize[2]);
				topPoint[i].init(0, 0 + cubeSize[1], 0 - cubeSize[2]);
			}
		}
					 */
		xPlane[0][0] = bottomPoint[0];
		xPlane[0][1] = bottomPoint[3];
		xPlane[0][2] = topPoint[3];
		xPlane[0][3] = topPoint[0];

		xPlane[1][0] = bottomPoint[1];
		xPlane[1][1] = bottomPoint[2];
		xPlane[1][2] = topPoint[2];
		xPlane[1][3] = topPoint[1];

		yPlane[0][0] = bottomPoint[0];
		yPlane[0][1] = bottomPoint[1];
		yPlane[0][2] = bottomPoint[2];
		yPlane[0][3] = bottomPoint[3];

		yPlane[1][0] = topPoint[0];
		yPlane[1][1] = topPoint[1];
		yPlane[1][2] = topPoint[2];
		yPlane[1][3] = topPoint[3];

		zPlane[0][0] = bottomPoint[0];
		zPlane[0][1] = bottomPoint[1];
		zPlane[0][2] = topPoint[1];
		zPlane[0][3] = topPoint[0];

		zPlane[1][0] = bottomPoint[3];
		zPlane[1][1] = bottomPoint[2];
		zPlane[1][2] = topPoint[2];
		zPlane[1][3] = topPoint[3];


	}
	void setxgacdo(int x)
	{
		gacdo.x = x;
	}
	void setygacdo(int y)
	{
		gacdo.y = y;
	}
	void setzgacdo(int z)
	{
		gacdo.z = z;
	}
	void plusxgacdo(int x)
	{
		gacdo.x += x;
	}
	void plusygacdo(int y)
	{
		gacdo.y += y;
	}
	void pluszgacdo(int z)
	{
		gacdo.z += z;
	}
	void draw(){
		
		/*
		glColor3f(0, 0, 0);
		glBegin(GL_LINE_LOOP);
		glVertex3f(yPlane[1][0].x+100, yPlane[1][0].y, yPlane[1][0].z);
		glVertex3f(yPlane[1][1].x+100, yPlane[1][1].y, yPlane[1][1].z);
		glVertex3f(yPlane[1][2].x+100, yPlane[1][2].y, yPlane[1][2].z);
		glVertex3f(yPlane[1][3].x+100, yPlane[1][3].y, yPlane[1][3].z);
		glEnd();
		  */
		//glMatrixMode(GL_MODELVIEW);
		//glTranslatef(pos.x, pos.y, pos.z);
	//	glLoadIdentity();

	/*	glTranslatef(pos.x, pos.y, pos.z);
		glRotatef(gacdo.x, 1, 0, 0);
		glRotatef(gacdo.y, 0, 1, 0);
		glRotatef(gacdo.z, 0, 0, 1);
		glTranslatef(-pos.x, -pos.y, -pos.z);
	  */
		//glLoadIdentity();

		//glTranslatef(0, 0, 0);

		glColor3f(color.x, color.y, color.z);

		
		GLfloat gray[] = { 0.75f, 0.75f, 0.75f, 1.0f };
		//GLfloat  specref[] = { 1.0f, 0.0f, 1.0f,1.0f };
		GLfloat  specref[] = { 10.0f, 30.0f, 10.0f, 10.0f };
		GLfloat ambientLight[] = { 0.0f, 1.0f, 0.0f, 1.0f };

		//glEnable(GL_LIGHTING);
		
		
		// ���� �÷� Ʈ��ŷ�� �����Ѵ�.
	
	

	//	glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);
		//glEnable(GL_COLOR_MATERIAL);
		glEnable(GL_COLOR_MATERIAL);
		glColorMaterial(GL_FRONT, GL_AMBIENT_AND_DIFFUSE);
	//	glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
		//glMateriali(GL_FRONT, GL_SHININESS, 128);
		
		
		glMaterialfv(GL_FRONT, GL_AMBIENT, gray);
		glMaterialfv(GL_FRONT, GL_SPECULAR, specref);
		glMateriali(GL_FRONT, GL_SHININESS, 100);
		  
			
		
		glMaterialfv(GL_BACK, GL_AMBIENT, gray);
		glMaterialfv(GL_BACK, GL_SPECULAR, specref);
		glMateriali(GL_BACK, GL_SHININESS, 100);
		  

	//	glShadeModel(GL_SMOOTH);
		
		glBegin(GL_QUADS); //�ظ�
		//glBegin(GL_POLYGON);
		//�� ������ ���� �������Ͱ� ���ƾ� ���̳���.
		//������ 0���ϋ� ����.
		for (int i = 0; i < 4; ++i)
		{
			Point3d vec = Normalvec(yPlane[0][i - 1], yPlane[0][i + 1]);

			if (i == 0)
			{
				Point3d vec = Normalvec(yPlane[0][i+1], yPlane[0][3]);
			}
			if (i == 3)
			{
				Point3d vec = Normalvec(yPlane[0][0], yPlane[0][2]);
			}
			glNormal3f(vec.x,vec.y,vec.z);
			//glNormal3f(0, 1.0, 0);
			glVertex3d(yPlane[0][i].x, yPlane[0][i].y, yPlane[0][i].z);
		}
		//glEnd();
		//glBegin(GL_QUADS); //����
		//glNormal3f(0, -1, 0);
		for (int i = 0; i < 4; ++i)
		{
			Point3d vec = Normalvec(yPlane[1][i - 1], yPlane[1][i + 1]);

			if (i == 0)
			{
				Point3d vec = Normalvec(yPlane[1][i + 1], yPlane[1][3]);
			}
			if (i == 3)
			{
				Point3d vec = Normalvec(yPlane[1][0], yPlane[1][2]);
			}
			glNormal3f(vec.x, vec.y, vec.z);

			glVertex3d(yPlane[1][i].x, yPlane[1][i].y, yPlane[1][i].z);
		}
		//glEnd();
		//glBegin(GL_QUADS); //���ʸ�
		//glNormal3f(-1, 0, 0);
		for (int i = 0; i < 4; ++i)
		{
			Point3d vec = Normalvec(xPlane[0][i - 1], xPlane[0][i + 1]);

			if (i == 0)
			{
				Point3d vec = Normalvec(xPlane[0][i + 1], xPlane[0][3]);
			}
			if (i == 3)
			{
				Point3d vec = Normalvec(xPlane[0][0], xPlane[0][2]);
			}
			glNormal3f(vec.x, vec.y, vec.z);

			glVertex3d(xPlane[0][i].x, xPlane[0][i].y, xPlane[0][i].z);

		}
		//glBegin(GL_QUADS); //�����ʸ�
		for (int i = 0; i < 4; ++i)
		{
			Point3d vec = Normalvec(xPlane[1][i - 1], xPlane[1][i + 1]);

			if (i == 0)
			{
				Point3d vec = Normalvec(xPlane[1][i + 1], xPlane[1][3]);
			}
			if (i == 3)
			{
				Point3d vec = Normalvec(xPlane[1][0], yPlane[1][2]);
			}
			glNormal3f(vec.x, vec.y, vec.z);

			glVertex3d(xPlane[1][i].x, xPlane[1][i].y, xPlane[1][i].z);


		}
		//glEnd();
		//glBegin(GL_QUADS); //�޸�
		//glNormal3f(0, 0, 1);
		for (int i = 0; i < 4; ++i)
		{
			Point3d vec = Normalvec(zPlane[0][i - 1], zPlane[0][i + 1]);

			if (i == 0)
			{
				Point3d vec = Normalvec(zPlane[0][i + 1], zPlane[0][3]);
			}
			if (i == 3)
			{
				Point3d vec = Normalvec(zPlane[0][0], zPlane[0][2]);
			}
			glNormal3f(vec.x, vec.y, vec.z);

			glVertex3d(zPlane[0][i].x, zPlane[0][i].y, zPlane[0][i].z);

		}
		//glEnd();
		//glBegin(GL_QUADS); //��
		//glNormal3f(0, 0, -1);
		for (int i = 0; i < 4; ++i)
		{
			Point3d vec = Normalvec(zPlane[1][i - 1], zPlane[1][i + 1]);

			if (i == 0)
			{
				Point3d vec = Normalvec(zPlane[1][i + 1], zPlane[1][3]);
			}
			if (i == 3)
			{
				Point3d vec = Normalvec(zPlane[1][0], zPlane[1][2]);
			}
			glNormal3f(vec.x, vec.y, vec.z);

			glVertex3d(zPlane[1][i].x, zPlane[1][i].y, zPlane[1][i].z);

		}
		glEnd();

		/*
		glBegin(GL_QUADS); //�ظ�
		//glBegin(GL_POLYGON);
		//�� ������ ���� �������Ͱ� ���ƾ� ���̳���.
		//������ 0���ϋ� ����.
		for (int i = 0; i < 4; ++i)
		{
			glNormal3f(0, 1.0, 0);
			glVertex3d(yPlane[0][i].x, yPlane[0][i].y, yPlane[0][i].z);
		}
		//glEnd();
		//glBegin(GL_QUADS); //����
		//glNormal3f(0, -1, 0);
		for (int i = 0; i < 4; ++i)
		{
			glNormal3f(0, 1.0,-0.2*i);
			glVertex3d(yPlane[1][i].x, yPlane[1][i].y, yPlane[1][i].z);
		}
		//glEnd();
		//glBegin(GL_QUADS); //���ʸ�
		//glNormal3f(-1, 0, 0);
		for (int i = 0; i < 4; ++i)
		{
			glNormal3f(0.2*i, 1.0+0.1*i, -0.2*i);
			//glNormal3f(-0.3*i, 1.0*i, -0.2*i);
			glVertex3d(xPlane[0][i].x, xPlane[0][i].y, xPlane[0][i].z);

		}
		//glEnd();
		//glBegin(GL_QUADS); //�����ʸ�
		//glNormal3f(1, 0, 0);
		for (int i = 0; i < 4; ++i)
		{
			glNormal3f(0.3*i, 1.0*i, -0.8*i);
			glVertex3d(xPlane[1][i].x, xPlane[1][i].y, xPlane[1][i].z);


		}
		//glEnd();
		//glBegin(GL_QUADS); //�޸�
		//glNormal3f(0, 0, 1);
		for (int i = 0; i < 4; ++i)
		{
			glNormal3f(-0.2*i, 1-i*0.1, -0.2*i);
			glVertex3d(zPlane[0][i].x, zPlane[0][i].y, zPlane[0][i].z);

		}
		//glEnd();
		//glBegin(GL_QUADS); //��
		//glNormal3f(0, 0, -1);
		for (int i = 0; i < 4; ++i)
		{
			glNormal3f(-0.2*i, 0.5, -1);
			glVertex3d(zPlane[1][i].x, zPlane[1][i].y, zPlane[1][i].z);

		}
		glEnd();
		  */
	}
};

#endif
