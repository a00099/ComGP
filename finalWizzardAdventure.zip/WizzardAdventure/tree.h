
#ifndef TREE__H__
#define TREE__H__

#include "Point3d.h"
#include "Cube.h"
#include <gl/glut.h>
#include <stdlib.h>
#include "baseobj.h"
#include <math.h>

#define RAD 57.32

class tree :public baseobj{
public:
	//�ִϸ��̼�
	//��Ȳ���°� ������������ kind1 ����        2 ~~ init 
	Cube treeobj[2];
	//Cube colliderbox;
	//int fireballrange = 100;
	int leggacdo = 0;
	int standtime = 0;
	int gacdostate = 0;
	Point3d gacdopos;
	int objgacdo = 0;

	int movecount = 10;
	int attackdistance = 70;
	int followmode = 0;
	int MState = 0;
	int animationcount = 5;
	int treekind = 0;
	int effecttime = 0;

	tree(int x, int y, int z,int treekind=0)
	{
			   
			pos.x = x;
			pos.y = y;
			pos.z = z;

			//���� x y ��ũ�� 30
			/*
			collidersize.x = 30;
			collidersize.y = 30;
			collidersize.z = -78;
			*/
			   
			
			if (treekind == 0)
			{
				treeobj[0].setcolor(0.5, 0.25, 0); //����
				treeobj[1].setcolor(0, 255, 0);


			}
	}

	void update()
	{
	

		//colliderbox.init(pos.x, pos.y, pos.z, collidersize.x, collidersize.y, -collidersize.z);

		if (treekind == 0)
		{
			//������ũ�⸦ 200������´� �� 75~125 �� Ʈ���� �׷�����. z����
			treeobj[0].init(pos.x + 75, pos.y, pos.z-75, 50, 500, 50);	  //��ġ�ְ� x y z 
			treeobj[1].init(pos.x , pos.y + 500, pos.z , 200, 200, 200);


			for (int i = 0; i < 2; ++i)
				treeobj[i].update();


		}
	}


	
	void draw()
	{

		if (treekind == 0)
		{
			treeobj[0].draw();
			glLoadIdentity();
			treeobj[1].draw();
			glLoadIdentity();

		}

	}


};

#endif