

#ifndef POTION__H__
#define POTION__H__

#include "Point3d.h"
#include "Cube.h"
#include <gl/glut.h>
#include <stdlib.h>
#include "baseobj.h"
#include <math.h>

#define RAD 57.32

class potion :public baseobj{
public:
	//�ִϸ��̼�
	//��Ȳ���°� ������������ kind1 ����        2 ~~ init 
	Cube fireball[4];
	Cube icestrike[9];
	Cube colliderbox;
	//int fireballrange = 100;
	int leggacdo = 0;
	int standtime = 0;
	int gacdostate = 0;
	Point3d gacdopos;
	int objgacdo = 0;

	int movecount = 10;
	int attackdistance = 70;
	int followmode = 0;
	int MState = 0;
	int animationcount = 5;
	int effectkind = 0;
	int effecttime = 0;
	double yspeed = 0;
	int damage = 50;

	potion(int x, int y, int z)
	{
		
			effecttime = 1000;
			pos.x = x;
			pos.y = y;
			pos.z = z;

			//���� x y ��ũ�� 30
			/*
			collidersize.x = 30;
			collidersize.y = 30;
			collidersize.z = -78;
			*/
			collidersize.x = 100;
			collidersize.y = 100;
			collidersize.z = -100;
			for (int i = 0; i < 4; ++i)
				fireball[i].setcolor(1, 0, 0.1*i);


		
	}

	void update()
	{
		if (effecttime >= 0)
		{
			effecttime -= 1;
		}
			colliderbox.init(pos.x, pos.y, pos.z, collidersize.x, collidersize.y, -collidersize.z);
			fireball[0].init(pos.x + 11, pos.y + 11, pos.z, 8, 8, 8);
			fireball[1].init(pos.x + 7, pos.y + 7, pos.z - 8, 16, 16, 16);
			fireball[2].init(pos.x + 3, pos.y + 3, pos.z - 24, 24, 24, 24);
			fireball[3].init(pos.x, pos.y, pos.z - 48, 30, 30, 30);

			for (int i = 0; i < 4; ++i)
				fireball[i].update();

		

		
	}


	int collider(baseobj *obj)
	{
		////if������Ʈ�̸��� floor�ΰ�� y���浹üũ�� 
		//if ((obj->pos.x<(pos.x + (collidersize.x / 2))) && (obj->pos.x + obj->collidersize.x>(pos.x + (collidersize.x / 2))))
		//{
		//   if ((obj->pos.z > (pos.z + (collidersize.z / 2))) && (obj->pos.z + obj->collidersize.z < (pos.z + (collidersize.z / 2))))

		//   {
		//      if ((pos.y - (obj->pos.y + obj->collidersize.y)) >= 0 && (pos.y - (obj->pos.y + obj->collidersize.y)) <= 10)
		//      {
		//         //�ٴڰ� ĳ���� ĳ��-�ٴ��� 0~10�����ΰ��
		//         if (minpos[0] == -1 && maxpos[0] == -1)
		//         {
		//            minpos[0] = obj->pos.x + obj->collidersize.x;
		//            maxpos[0] = obj->pos.x;

		//            minpos[1] = obj->pos.z + obj->collidersize.z;
		//            maxpos[1] = obj->pos.z;

		//         }

		//         pos.y = obj->pos.y + obj->collidersize.y;
		//         return 1;
		//      }
		//   }
		//}

		return 0;
	}

	void draw()
	{


		//colliderbox.draw();
		//glLoadIdentity();

		
			fireball[0].draw();
			glLoadIdentity();

		
			fireball[1].draw();
			glLoadIdentity();

		
			fireball[2].draw();
			glLoadIdentity();

	
			fireball[3].draw();
			glLoadIdentity();
	}

	


};

#endif