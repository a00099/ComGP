#ifndef POINT3D__H__
#define POINT3D__H__

#include<GL/glut.h>
typedef struct Point3d{
	double x = 0, y = 0, z = 0;
	void init(double a, double b, double c){
		x = a;
		y = b;
		z = c;
	}
}Point3d;

#endif